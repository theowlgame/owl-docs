# Table of contents

* [About RichBitz](README.md)

## Info

* [Supported Tokens](info/supported-tokens.md)
* [Fairness & Certificates](info/certificates.md)
* [Terms and Condition](info/terms-and-condition.md)
* [Bonus Terms and Conditions](info/bonus-terms-and-conditions.md)
* [Privacy Policy](info/privacy-policy.md)
* [AML Policy](info/aml-policy.md)
* [Self-Exclusion Terms and Condition](info/self-exclusion-terms-and-condition.md)
* [Responsible Gambling](info/responsible-gambling.md)
