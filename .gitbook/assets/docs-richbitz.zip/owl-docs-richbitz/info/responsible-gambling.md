# Responsible Gambling

If you have any concerns about your gambling habits and feel that you can’t follow these recommendations, we urge you to seek advice from accredited organizations that can offer support and advice, such as

[GamCare](http://www.gamcare.org.uk/)

[Keep It Fun ](https://keepitfun.rank.com/)

[Gambling Therapy](https://www.gamblingtherapy.org/)

## Underage

If you wish to gamble with us at RichBitz, you must be over 18 years of age or the legal minimum age for gambling in the jurisdiction you reside in under the laws applicable to you.

We recommended if you have any minors living in your household, to review the following parental control software links, which could prove a useful tool, regarding control and restrictions of the content accessible on your devices.

[https://www.netnanny.com/](https://www.netnanny.com/)&#x20;

[https://www.cyberpatrol.com/](https://www.cyberpatrol.com/)
