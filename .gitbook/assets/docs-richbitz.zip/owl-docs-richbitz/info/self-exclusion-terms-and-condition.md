# Self-Exclusion Terms and Condition

You can perform a self-exclusion in your profile page.&#x20;
