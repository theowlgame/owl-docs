# Fairness & Certificates

RichBitz only works with prestigious gaming providers such as Evolution, MicroGaming, Pragmatic Play, which they guarantee fairness of the games provided.&#x20;

&#x20;

{% file src="../.gitbook/assets/Evolution group ISO 27001 2021-01.pdf" %}
Evolution Group Audit Report
{% endfile %}

{% file src="../.gitbook/assets/246sy-246-evl-20-001-uk-agta-01-report_en.pdf" %}
Evolution Group Audit Report
{% endfile %}
