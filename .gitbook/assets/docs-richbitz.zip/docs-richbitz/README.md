# About RichBitz

#### **RichBitz: Leading Crypto Casino Solution Web 3.0**

RichBitz aims to provide seamless, fun, profitable gaming experience on most EVM compatible networks, near, and terra networks.&#x20;



