# Bonus Terms and Conditions

1. When you claim the bonus, it will be added to your RichBitz wallet, symbol is 'USDo'.
2. The USDo credit you get can only be used to play slots game.
3. If you reach wagering requirement, you can withdraw USDo to normal USDt wallet. Once you request a withdrawal, your USDo credit balance will be **zero out**. No winnings accrued in connection with any Free Bonus may be withdrawn/transferred until the wagering requirements have been met.
4. The maximum winnings that will be paid out resulting from a bonus or free spins that you've gotten from us for free, will be 100 USDT.  Any winnings exceeding this amount will be **forfeited**.&#x20;
5. There is a max bet limit for betting using the bonus USDo. If you bet bigger than the bet limit, your bet will be rejected.&#x20;
6. Please note that different games contribute to a different percentage towards the wagering requirements. Slots contribute 100% (aside from the excluded ones below), while house games contribute 50%.
7. The USDo credit you claim has an expiration, once reached expiration, if you haven't meet the wager requirement, or you haven't request a withdrawal, whether or not your USDo credit has profits or not, the remaining USDo credit balance will be zero out.&#x20;
8. You can not claim multiple bonus at the same time at the moment.&#x20;
9. All customer offers are limited to one per person, family, household address, email address, telephone number, same payment account number (e.g. debit or credit card, NETeller etc), IP, or shared computer, e.g. public library or workplace.
10. We reserve the right to not pay players who exploits our bonus system.
11. Players with disposable email addresses are not eligible for any free spins without deposit. If a player despite this would receive free spins without a deposit being made, all winnings from the spins will be confiscated.

## Common Errors for Bonus Claim

### You are not eligible to claim this promo code.

Certain promo code requires that you do not have an inviter. If you already have an inviter, you can't claim it.

### This email address is not supported.

To prevent exploits of our promo code, we use a whitelist of email providers. If you think your email should be whitelisted, please contact support. Please pay attention that players with disposable email addresses are not eligible for any free spins without deposit. If a player despite this would receive free spins without a deposit being made, all winnings from the spins will be confiscated.

